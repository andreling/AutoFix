package com.example.se;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<kendaraan> kendaraans = new ArrayList<>();
    public static ArrayList<User> user = new ArrayList<>();
    public static ArrayList<service> services = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user.add(new User("Angel","admin","08996571623","Jl. Raya Kb. Jeruk No.27","Angel@binus.ac.id"));
        kendaraans.add(new kendaraan("kawasaki",1299,"ninja h2","b0001"));
        kendaraans.add(new kendaraan("ducati",1299,"ducati 1299","b0002"));
        services.add(new service("oli","Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod"));
        services.add(new service("ban","Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod"));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this,Login.class);
                startActivity(intent);
                finish();
            }
        }, 2000);
    }
    }


