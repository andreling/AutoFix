package com.example.se;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class OngoingAdapter extends RecyclerView.Adapter<OngoingAdapter.OngoingViewHolder>{
    ArrayList<Transaction> transactions;
    Context context;

    public OngoingAdapter(Context context,ArrayList<Transaction> transactions) {
        this.context = context;
        this.transactions = transactions;
    }

    @NonNull


    @Override
    public OngoingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.layout_ongoing_detail, parent, false);
        OngoingViewHolder ViewHolder = new OngoingViewHolder(itemView);
        return ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull OngoingAdapter.OngoingViewHolder holder, int position) {
        String _nama = transactions.get(position).nama;
        String _service = transactions.get(position).service;
        String _waktu = transactions.get(position).waktu;

        holder.nama.setText(_nama);
        holder.service.setText(_service);
        holder.waktu.setText(_waktu);

    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public class OngoingViewHolder extends RecyclerView.ViewHolder{

        TextView nama;
        TextView service;
        TextView waktu;
        public OngoingViewHolder(@NonNull View itemView) {
            super(itemView);
            nama = itemView.findViewById(R.id.ongoing_kendaraan);
            service = itemView.findViewById(R.id.ongoing_service);
            waktu = itemView.findViewById(R.id.ongoing_waktu_service);
        }
    }
}


