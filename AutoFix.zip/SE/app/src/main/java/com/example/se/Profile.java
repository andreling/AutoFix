package com.example.se;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

public class Profile extends AppCompatActivity {

    ImageButton motor_add;
    ImageButton profile_edit;
    TextView name;
    TextView phone;
    TextView email;
    ImageButton back_button;
    EditText profile_merek;
    EditText profile_cc;
    EditText profile_tipe;
    EditText profile_plat;
    AppCompatButton submit_button;
    RecyclerView recyclerView;
    MainAdapter mainAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        name = findViewById(R.id.profile_name);
        phone = findViewById(R.id.profile_phone);
        email = findViewById(R.id.profile_email);
        back_button = findViewById(R.id.back_button_profile);
        profile_edit = findViewById(R.id.profile_edit);
        recyclerView = findViewById(R.id.motor_recycle);
        motor_add = findViewById(R.id.motor_add);
        LinearLayoutManager layoutManager = new LinearLayoutManager(Profile.this,LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        name.setText(MainActivity.user.get(0).name);
        phone.setText(MainActivity.user.get(0).phone);
        email.setText(MainActivity.user.get(0).email);
        mainAdapter = new MainAdapter(Profile.this, MainActivity.kendaraans);
        recyclerView.setAdapter(mainAdapter);
        motor_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Profile.this);
                bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog);
                bottomSheetDialog.setCanceledOnTouchOutside(false);

                profile_merek = bottomSheetDialog.findViewById(R.id.merek_profile);
                profile_cc = bottomSheetDialog.findViewById(R.id.cc_profile);
                profile_tipe = bottomSheetDialog.findViewById(R.id.tipe_profile);
                profile_plat = bottomSheetDialog.findViewById(R.id.plat_profile);
                submit_button = bottomSheetDialog.findViewById(R.id.bottom_button);

                submit_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String value= profile_cc.getText().toString();
                        int finalValue=Integer.parseInt(value);
                        MainActivity.kendaraans.add(new kendaraan(profile_merek.getText().toString(),finalValue,profile_tipe.getText().toString(),profile_plat.getText().toString()));
                        mainAdapter.notifyDataSetChanged();
                        bottomSheetDialog.dismiss();

                    }
                });

                bottomSheetDialog.show();

            }
        });

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });

        profile_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this,ProfileEdit.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        name.setText(MainActivity.user.get(0).name);
        phone.setText(MainActivity.user.get(0).phone);
        email.setText(MainActivity.user.get(0).email);
    }
}