package com.example.se;

public class kendaraan {
    String merek;
    Integer cc;
    String tipe;
    String plat;

    public kendaraan(String merek, Integer cc, String tipe, String plat) {
        this.merek = merek;
        this.cc = cc;
        this.tipe = tipe;
        this.plat = plat;
    }

    public String getMerek() {
        return merek;
    }

    public void setMerek(String merek) {
        this.merek = merek;
    }

    public Integer getCc() {
        return cc;
    }

    public void setCc(Integer cc) {
        this.cc = cc;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getPlat() {
        return plat;
    }

    public void setPlat(String plat) {
        this.plat = plat;
    }

    @Override
    public String toString() {
        return tipe;
    }

}
