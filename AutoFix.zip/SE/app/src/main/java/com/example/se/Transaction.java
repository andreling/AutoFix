package com.example.se;

public class Transaction {
    String service;
    String waktu;
    String nama;

    public Transaction(String service, String waktu, String nama) {
        this.service = service;
        this.waktu = waktu;
        this.nama = nama;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}
