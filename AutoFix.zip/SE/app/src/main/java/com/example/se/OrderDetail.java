package com.example.se;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class OrderDetail extends AppCompatActivity implements View.OnClickListener {

    AppCompatButton order;
    String kendaraan;
    String waktu;
    String alamat;
    Integer value;
    ImageButton back;

    TextView alamat_text;
    TextView kendaraan_text;
    TextView service_text;
    TextView waktu_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        Bundle extras = getIntent().getExtras();
        kendaraan = extras.getString("kendaraan");
        waktu = extras.getString("waktu");
        alamat = extras.getString("alamat");
        value = getIntent().getIntExtra("servicevalue",0);

        alamat_text = findViewById(R.id.alamat_text);
        alamat_text.setText(alamat);
        kendaraan_text = findViewById(R.id.type_kendaraan);
        kendaraan_text.setText(kendaraan);
        service_text = findViewById(R.id.type_service);
        service_text.setText(MainActivity.services.get(value).tipe_service.toString());
        waktu_text = findViewById(R.id.type_waktu_service);
        waktu_text.setText(waktu);

        back = findViewById(R.id.back_button_order_detail);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });



        order = findViewById(R.id.order_button);
        order.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        OngoingDetail.transactions.add(new Transaction(MainActivity.services.get(value).tipe_service.toString(),waktu,kendaraan));
        Intent intent = new Intent(OrderDetail.this,payment.class);
        startActivity(intent);
    }
}