package com.example.se;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText email;
    EditText password;

    AppCompatButton login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.Login_email);
        password =findViewById(R.id.Login_password);

        login = findViewById(R.id.login_button);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(email.length() == 0 && password.length() == 0){
                    Toast.makeText(view.getContext(),"Email and Password cannot be empty" , Toast.LENGTH_LONG).show();
                }
                else{
                    if(email.getText().toString().equals("admin") && password.getText().toString().equals("admin")){
                        startActivity(new Intent(getApplicationContext(),Home.class));
                    }
                    else{
                        Toast.makeText(view.getContext(),"Wrong Email or Password" , Toast.LENGTH_LONG).show();

                    }
                }


            }
        });
    }
}