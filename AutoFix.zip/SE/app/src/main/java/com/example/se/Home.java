package com.example.se;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.INotificationSideChannel;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

    TextView home_title;
    ImageButton profile_btn;
    ImageButton oil_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        oil_button = findViewById(R.id.oiloption);
        profile_btn = findViewById(R.id.profile_button);
        home_title = findViewById(R.id.home_title);

        home_title.setText("Hi " +MainActivity.user.get(0).name );

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home_page);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.pesanan_page:
                        startActivity(new Intent(getApplicationContext(),OngoingOrder.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home_page:
                        return true;
                    case R.id.promo_page:
                        startActivity(new Intent(getApplicationContext(),Promo.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

        oil_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = 0;
                Intent intent = new Intent(Home.this,Order.class);
                intent.putExtra("value",i);
                startActivity(intent);
            }
        });
        profile_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this,Profile.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        home_title.setText("Hi " +MainActivity.user.get(0).name );
    }
}