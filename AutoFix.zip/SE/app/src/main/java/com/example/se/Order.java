package com.example.se;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Order extends AppCompatActivity {

    EditText DateTime;
    CheckBox checkBox;
    EditText address;
    Spinner spinner;
    ImageButton next;
    ImageButton back;

    ImageView image;
    TextView image_text;
    Integer image_value;
    Integer value;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        back = findViewById(R.id.back_button);
        value = getIntent().getIntExtra("value",0);
        image = findViewById(R.id.main_image);
        image_text = findViewById(R.id.main_image_text);
        if(value == 0){
            image_value = R.drawable.oil;
            image_text.setText(MainActivity.services.get(value).desc.toString());
        }
        image.setImageResource(image_value);

        ArrayAdapter<kendaraan> adapter = new ArrayAdapter<kendaraan>(
                this,
                R.layout.drop_down,
                MainActivity.kendaraans
        );

        spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

        DateTime = findViewById(R.id.datetime);
        DateTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowDateTimeDialog(DateTime);
            }
        });
        address = findViewById(R.id.address);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        checkBox = findViewById(R.id.checkbox2);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(checkBox.isChecked()){
                    address.setText(MainActivity.user.get(0).address);
                }
                else{
                    address.setText("");
                }
            }
        });

        next = findViewById(R.id.next_button);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(Order.this,OrderDetail.class);
                intent.putExtra("kendaraan",spinner.getSelectedItem().toString());
                intent.putExtra("waktu",DateTime.getText().toString());
                intent.putExtra("alamat",address.getText().toString());
                intent.putExtra("servicevalue",value);
                startActivity(intent);
            }
        });

    }

    private void ShowDateTimeDialog(EditText dateTime) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,day);

                TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hour);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat= new SimpleDateFormat("yy-MM-dd HH:mm");
                        dateTime.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(Order.this,timeSetListener,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();


            }
        };
        new DatePickerDialog(Order.this,dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
    }
}