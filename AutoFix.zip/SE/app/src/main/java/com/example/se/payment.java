package com.example.se;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class payment extends AppCompatActivity implements View.OnClickListener {
    ImageButton pay1;
    ImageButton pay2;
    ImageButton pay3;
    ImageButton pay4;
    ImageButton pay5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        pay1 = findViewById(R.id.pay1);
        pay2 = findViewById(R.id.pay2);
        pay3 = findViewById(R.id.pay3);
        pay4 = findViewById(R.id.pay4);
        pay5 = findViewById(R.id.pay5);

        pay1.setOnClickListener(this);
        pay2.setOnClickListener(this);
        pay3.setOnClickListener(this);
        pay4.setOnClickListener(this);
        pay5.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(payment.this,PaymentSuccess.class);
        startActivity(intent);
    }
}