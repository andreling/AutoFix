package com.example.se;

public class service {
    String tipe_service;
    String desc;

    public service(String tipe_service, String desc) {
        this.tipe_service = tipe_service;
        this.desc = desc;
    }

    public String getTipe_service() {
        return tipe_service;
    }

    public void setTipe_service(String tipe_service) {
        this.tipe_service = tipe_service;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
