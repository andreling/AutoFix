package com.example.se;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

public class ProfileEdit extends AppCompatActivity {

    EditText name;
    EditText email;
    EditText phone;
    EditText address;
    AppCompatButton save;
    ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);

        name =  findViewById(R.id.edit_name);
        back = findViewById(R.id.back_button_edit);
        email = findViewById(R.id.edit_email);
        phone = findViewById(R.id.edit_phone);
        address = findViewById(R.id.edit_address);
        save = findViewById(R.id.edit_save_button);

        name.setText(MainActivity.user.get(0).name);
        phone.setText(MainActivity.user.get(0).phone);
        email.setText(MainActivity.user.get(0).email);
        address.setText(MainActivity.user.get(0).address);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.user.get(0).setName(name.getText().toString());
                MainActivity.user.get(0).setPhone(phone.getText().toString());
                MainActivity.user.get(0).setEmail(email.getText().toString());
                MainActivity.user.get(0).setAddress(address.getText().toString());
                finish();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }
}